#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include "voidsAuxiliares.h"
using namespace std;
#define clavetrue 2018

int claveacceso;
main(void){
	
	do{
		cout<<"INGRESE LA CLAVE DE ACCESO";
		cin>>claveacceso;
		if (claveacceso!=clavetrue);
	}while(claveacceso!=clavetrue);
		alinear(2);
		cout<<"Acceso Concedido";
		getch();
		system ("Cls");
}
