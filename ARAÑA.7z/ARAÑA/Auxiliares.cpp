#include <iostream>
#include <fstream>
#include "Auxiliares.h"
FILE *doc;
using namespace std;

void alinear(int ciclos)
{
	for (int i=1;i<=ciclos;i++){
		cout<<endl;
	}
}
void titulo(){
	cout<<"WELCOME TO:";
	alinear(2);
cout<<"      AA                              ��  ��        		"<<endl;          
cout<<"     AAAA                               ��           	"<<endl;  
cout<<"    AA  AA                                           |	"<<endl;  
cout<<"    AA  AA        rrrrrr  aaaaaa    ��������    aaaaaa  	"<<endl;
cout<<"   AAAAAAAA       rr      aa  aa    ��    ��    aa  aa  	"<<endl;
cout<<"  AA      AA      rr      aaaaaa    ��    ��    aaaaaa  	"<<endl;
cout<<"  AA      AA      rr      aa  aa    ��    ��    aa  aa  	"<<endl;
cout<<"  AA      AA      rr      aa  aa    ��    ��    aa  aa   "<<endl;
}


	
	
	
	

