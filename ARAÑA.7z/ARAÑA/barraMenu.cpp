#include <iostream>
#include "barraMenu.h"
#include "registro.h"
#include "level.h"

using namespace std;

void menupartida() {	
		system("CLS");	
	bool salir = false;
	 
	while(salir == false) {
		char opcion;
		
		cout << "*********Elije Un Tema********" << endl;
		cout << "------------------------------" << endl;
		cout << "******************************" << endl;
		cout << endl;
		cout << "a- geografia" << endl;
		cout << "b - personajes" << endl;
		cout << "s - Salir" << endl;
		
		cout << endl;
		cout << endl;				
		cout << "Ingrese un numero del menu y presione enter --> ";
		cin >> opcion;
		
		switch(opcion) {
			case 'a':
				geografia();
				break;	
			case 'b':
			personajes();
				break;
			case 's':
				salir = true;
			default:
				break;
			
		}
		
		
	}
}

void menu() {
		system ("Cls");
	bool salir = false;
	
	while(salir == false) {
		char opcion;
		
		cout << "*********Menu********" << endl;
		cout << "------------------------------" << endl;
		cout << "******************************" << endl;
		cout << endl;
		cout << "a- Nueva Partida" << endl;
		cout << "b - Mejores Jugadores" << endl;
		cout << "s - Salir" << endl;
		
		cout << endl;
		cout << endl;				
		cout << "Ingrese un numero del menu y presione enter --> ";
		cin >> opcion;
		
		switch(opcion) {
			case 'a':
				 menupartida();
				break;	
			case 'b':
				mustraDatos();
				break;
			case 's':
				salir = true;
			default:
				break;
			
		}
		
			
	}
		
}

