//Preguntas GEOGRAFIA
void Gpreguntauno();
void Gpreguntados();
void Gpreguntatres();
void Gpreguntacuatro();
void Gpreguntacinco();
//Preguntas PERSONAJES
void Ppreguntauno();
void Ppreguntados();
void Ppreguntatres();
void Ppreguntacuatro();
void Ppreguntacinco();
//Preguntas FUTBOL
void Fpreguntauno();
void Fpreguntados();
void Fpreguntatres();
void Fpreguntacuatro();
void Fpreguntacinco();
//Resultados y Mejor Jugador
void resultados();

