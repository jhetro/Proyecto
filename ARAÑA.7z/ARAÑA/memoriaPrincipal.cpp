#include <iostream>
#include "seguridad.h"
#include "barraMenu.h"

using namespace std;

int main () {
	system("COLOR 0E0");
	if (login() == false) {
		return 1;
	}
	
	menu();
		
	return 0;
}

