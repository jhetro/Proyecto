#include<iostream>
#include <conio.h>
#include "level.h"
#include "preguntas.h"
#include "barraMenu.h"
#include "Auxiliares.h"

using namespace std;
	
void geografia(){

	cout<<"********************************"<<endl;
	cout<<"***********LEVEL ONE*************"<<endl;
	cout<<"Presione ENTER para Jugar"<<endl;
	getch();
				
				Gpreguntauno();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Gpreguntados();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Gpreguntatres();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Gpreguntacuatro();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Gpreguntacinco();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				resultados();								
	}

void futbol(){

	cout<<"********************************"<<endl;
	cout<<"***********LEVEL ONE*************"<<endl;
	cout<<"Presione ENTER para Jugar"<<endl;
	getch();
				
				Fpreguntauno();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Fpreguntados();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Fpreguntatres();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Fpreguntacuatro();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Fpreguntacinco();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				resultados();
				cout << "Presiona ENTER para continuar" << endl;									
	}
	void personajes(){

	cout<<"********************************"<<endl;
	cout<<"***********LEVEL ONE*************"<<endl;
	cout<<"Presione ENTER para Jugar"<<endl;
	getch();
				
				Ppreguntauno();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Ppreguntados();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Ppreguntatres();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Ppreguntacuatro();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				Ppreguntacinco();
				cout << "Presiona ENTER para continuar" << endl;
				getch();
				resultados();
				alinear(2);
				cout << "Presiona ENTER para continuar" << endl;
				getch();
													
	}


