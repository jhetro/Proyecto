#include <stdio.h>
#include <conio.h>

bool baseDeRegistro() {
	FILE *doc;
	char jug[5];
	char resp;
	int n=1;
	doc = fopen ("Jug.txt","a+");
	printf("ECRIBA NOMBRE DEL JUGADOR");

	
		if (doc == NULL){
		printf("Error de apertura");
		return 1;
		}
	do {
		 printf("\n Jugador %d :", n);
		 scanf ("%s",jug);
		 fprintf (doc, "%s \n", jug);
		 n++;
		 
		 printf("INGRESE NUEVO JUGADOR s/n");
		 resp = getch();
	}while (resp == 'S' && resp =='s');
	fclose(doc);
	return 0;
	

	
}

bool mustraDatos(){
FILE *nevo;
nevo = fopen ("Jug.txt","r");
int c;

while ( (c = getc(nevo)) != EOF){
	
	if (nevo == NULL){
		printf("Error de apertura");
		return 1;
	}
	
	if(c == '\n') printf("\n");
	else printf("%c ", c);
}
	fclose(nevo);
	return 0;
}

